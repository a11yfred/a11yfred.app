import { forwardRef, useEffect } from 'react'
import '@ulam/ube/core'

/**
 * React adapter for <ube-form-control-toggle>
 * Accessible switch/toggle input.
 *
 * Props match the original FormControlToggle component API:
 *   id: string
 *   checked: boolean
 *   onChange: function (checked: boolean)
 *   disabled: boolean
 *
 * Usage (same as before):
 *   <label htmlFor="live-search">
 *     <FormControlToggle id="live-search" checked={liveSearch} onChange={setLiveSearch} />
 *     Live search
 *   </label>
 */
const FormControlToggle = forwardRef(function FormControlToggle(
  {
    id,
    checked,
    onChange,
    disabled,
    ...rest
  },
  ref
) {
  useEffect(() => {
    if (!ref?.current) return
    const el = ref.current
    const handleChange = (e) => onChange(e.target.checked)
    el.addEventListener('change', handleChange)
    return () => el.removeEventListener('change', handleChange)
  }, [onChange, ref])

  return (
    <ube-form-control-toggle
      ref={ref}
      id={id}
      {...(checked && { checked: true })}
      {...(disabled && { disabled: true })}
      {...rest}
    />
  )
})

FormControlToggle.displayName = 'FormControlToggle'
export default FormControlToggle
