import { createPortal } from 'react-dom'
import { useState, useEffect } from 'react'

/**
 * OverlayShell (React adapter): Unified backdrop and portal renderer for all overlay types.
 *
 * Renders a single backdrop and the active overlay panel to document.body.
 * This ensures only one backdrop exists regardless of overlay type (dialog, sheet, drawer).
 * Uses vanilla core overlayShell functions for state management.
 *
 * Props:
 *   open: boolean - whether any overlay is open
 *   onBackdropClick: fn - handler when backdrop is clicked
 *   panelRef: React.RefObject - ref to attach to the overlay panel
 *   role: string - ARIA role (dialog, region, etc.)
 *   ariaModal: boolean - whether panel is aria-modal
 *   ariaLabel: string - accessible label for the panel
 *   className: string - CSS class for the panel
 *   children: node - overlay content
 *   backdropClass: string - CSS class for backdrop
 */
export default function OverlayShell({
  open,
  onBackdropClick,
  panelRef,
  role = 'dialog',
  ariaModal = true,
  ariaLabel,
  className,
  children,
  backdropClass = 'overlay-backdrop',
}) {
  const [isClosing, setIsClosing] = useState(false)
  const [lastOpen, setLastOpen] = useState(open)

  if (open !== lastOpen) {
    setLastOpen(open)
    if (open) setIsClosing(false)
    else setIsClosing(true)
  }

  useEffect(() => {
    if (isClosing) {
      const timer = setTimeout(() => {
        setIsClosing(false)
      }, 250)
      return () => clearTimeout(timer)
    }
  }, [isClosing])

  const renderOpen = open || isClosing

  if (!renderOpen) return null

  return createPortal(
    <>
      <div
        className={`${backdropClass}${open ? ' is-open' : ''}`}
        onClick={onBackdropClick}
        aria-hidden="true"
        data-overlay-backdrop
        data-component="unified-backdrop"
      />
      <div
        ref={panelRef}
        className={className}
        role={role}
        aria-modal={ariaModal ? true : undefined}
        aria-label={ariaLabel}
        tabIndex={-1}
        inert={!renderOpen || undefined}
      >
        {children}
      </div>
    </>,
    document.body
  )
}
