import { useRef } from 'react'
import OverlayShell from './OverlayShell.jsx'

/**
 * Dialog shell: structure only, no focus management or escape handling.
 * Use Dialog (from @ulam/sili/react) for the fully-wired React + sili version.
 *
 * Props:
 *   open          boolean
 *   onClose       fn
 *   heading       string
 *   headingIcon   ReactNode
 *   actions       [{ label, onClick, className }]
 *   panelRef      React.RefObject
 *   children      node
 */
export default function DialogShell({ open, onClose, heading = 'Information', headingIcon, actions, children, panelRef: externalPanelRef }) {
  const internalPanelRef = useRef(null)
  const panelRef = externalPanelRef ?? internalPanelRef

  return (
    <OverlayShell
      open={open}
      onBackdropClick={onClose}
      panelRef={panelRef}
      /* eslint-disable-next-line @a11yfred/neighbor/no-roles-without-name */
      role="dialog"
      ariaModal={true}
      ariaLabel={heading}
      className={`modal-panel${open ? ' is-open' : ''}`}
      backdropClass="modal-backdrop"
    >
      <div className="modal-body">
        <h2 className="modal-heading">
          {headingIcon && <span className="modal-heading-icon" aria-hidden="true">{headingIcon}</span>}
          {heading}
        </h2>
        <div className="modal-content">{children}</div>
      </div>
      <div className="modal-footer">
        {(actions ?? [{ label: 'OK', onClick: onClose, className: 'btn--primary modal-ok-btn' }])
          .map(action => (
            <button
              key={action.label}
              onClick={action.onClick}
              className={action.className ?? 'btn--primary modal-ok-btn'}
            >
              {action.label}
            </button>
          ))
        }
      </div>
    </OverlayShell>
  )
}
