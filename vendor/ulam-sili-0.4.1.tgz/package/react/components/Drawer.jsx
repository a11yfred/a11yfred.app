import { useRef } from 'react'
import OverlayShell from './OverlayShell.jsx'

/**
 * Drawer shell: structure only, no focus management or escape handling.
 * Use Drawer (from @ulam/sili/react) for the fully-wired React + sili version.
 *
 * Props:
 *   open         boolean
 *   onClose      fn
 *   label        string
 *   panelRef     React.RefObject
 *   children     node
 */
export default function DrawerShell({ open, onClose, label = 'Menu', children, panelRef: externalPanelRef }) {
  const internalPanelRef = useRef(null)
  const panelRef = externalPanelRef ?? internalPanelRef

  return (
    <OverlayShell
      open={open}
      onBackdropClick={onClose}
      panelRef={panelRef}
      /* eslint-disable-next-line @a11yfred/neighbor/no-roles-without-name */
      role="dialog"
      ariaModal={true}
      ariaLabel={label}
      className={`drawer-panel${open ? ' is-open' : ''}`}
      backdropClass="overlay-backdrop"
    >
      {children}
    </OverlayShell>
  )
}
