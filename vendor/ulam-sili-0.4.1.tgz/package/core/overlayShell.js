/**
 * Unified overlay shell: Single backdrop + portal renderer for all overlay types.
 *
 * Creates a single backdrop and overlay panel container to document.body.
 * Ensures only one backdrop exists regardless of overlay type (dialog, sheet, drawer).
 * Framework-agnostic vanilla JS; wrapped in React/Vue/Angular adapters.
 *
 * Returns: { backdrop, panel } — DOM elements you control
 *
 * Usage (vanilla):
 *   const { backdrop, panel } = createOverlayShell({
 *     backdropClass: 'modal-backdrop',
 *     panelClass: 'modal-panel',
 *     role: 'dialog',
 *     ariaLabel: 'Dialog Title',
 *   })
 *   panel.innerHTML = '<button>Close</button>'
 *   document.body.append(backdrop, panel)
 */

export function createOverlayShell(options = {}) {
  const {
    backdropClass = 'overlay-backdrop',
    panelClass = 'overlay-panel',
    role = 'dialog',
    ariaLabel = '',
    onBackdropClick = () => {},
  } = options

  // Create shared backdrop (one per app)
  const backdrop = document.createElement('div')
  backdrop.className = backdropClass
  backdrop.setAttribute('aria-hidden', 'true')
  backdrop.setAttribute('data-overlay-backdrop', '')
  backdrop.setAttribute('data-component', 'unified-backdrop')
  backdrop.addEventListener('click', onBackdropClick)

  // Create panel
  const panel = document.createElement('div')
  panel.className = panelClass
  panel.setAttribute('role', role)
  panel.setAttribute('aria-modal', 'true')
  if (ariaLabel) {
    panel.setAttribute('aria-label', ariaLabel)
  }
  panel.setAttribute('tabindex', '-1')

  return { backdrop, panel }
}

/**
 * Update backdrop visibility based on open state
 */
export function setOverlayOpen(backdrop, isOpen) {
  if (isOpen) {
    backdrop.classList.add('is-open')
  } else {
    backdrop.classList.remove('is-open')
  }
}

/**
 * Update panel visibility and inert state based on open state
 */
export function setOverlayPanelOpen(panel, isOpen) {
  if (isOpen) {
    panel.classList.add('is-open')
    panel.removeAttribute('inert')
  } else {
    panel.classList.remove('is-open')
    panel.setAttribute('inert', '')
  }
}

/**
 * Update panel role and aria-modal for different overlay types
 */
export function setOverlayRole(panel, role, ariaModal = true) {
  panel.setAttribute('role', role)
  if (ariaModal) {
    panel.setAttribute('aria-modal', 'true')
  } else {
    panel.removeAttribute('aria-modal')
  }
}
